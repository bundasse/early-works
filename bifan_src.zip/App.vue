<template>
  <NaviPage />
  <MainPage />
  <FooterPage />
</template>

<script>
import NaviPage from './components/Navi.vue'
import MainPage from './components/Main.vue'
import FooterPage from './components/Footer.vue'

export default {
  name: 'App',
  components: {
    NaviPage,
    MainPage,
    FooterPage
  }
}
</script>

<style>
</style>
