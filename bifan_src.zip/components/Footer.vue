<template>
    <div class="w-full bg-[#222222] pt-[41px] pb-[45px]">
        <div class="max-w-7xl mx-auto text-[#ababab] flex">
            <div><img :src="require(`@/assets/images/f_logo.png`)" alt="로고"></div>
            <div class="text-[11px] xl:text-sm spoqa font-light ml-[45px]">
                <p>
                    <span class="text-white after:inline-block after:w-0.5 after:h-2.5 after:bg-[#ababab] after:mx-2.5"><a href="#">이용약관</a></span>
                    <span class="text-[#61b3b0] after:inline-block after:w-0.5 after:h-2.5 after:bg-[#ababab] after:mx-2.5"><a href="#">개인정보취급방침</a></span>
                    <span class="text-white"><a href="#">이메일 무단수집거부</a></span>
                </p>
                <address class="mt-[5px] not-italic">
                    <span v-for="e in data[0].footer" :key="e" class="after:inline-block after:w-0.5 after:h-2.5 after:bg-[#ababab] after:mx-2.5 last-of-type:after:hidden">{{ e }}</span>
                </address>
                <p class="mt-[6px]">Copyright © BIFAN All right Reserved.</p>
            </div>
        </div>
    </div>
</template>
<script>
  import data from '../assets/Data.json';
export default {
    name: "FooterPage",
    data() {
        return {
            data : data
        }
    },
}
</script>
<style>
    .anemonesq{
    font-family: 'Cafe24Ohsquare';
}
    .anemoneair{
        font-family: 'Cafe24Ohsquareair';
    }
    .spoqa{
    font-family: 'SpoqaHanSansNeo-Regular';
    }
</style>