<template>
    <div class="w-full bg-[#6dd2cd] text-white text-xs font-bold Spoqa">
        <div class="max-w-7xl mx-auto relative py-3">
            <ul class="flex">
                <li class="px-3 py-1 bg-white text-[#6dd2cd] rounded-full">BIFAN</li>
                <li class="px-3 py-1 relative after:absolute after:w-0.5 after:h-0.5 after:rounded-full after:bg-white after:top-2.5 after:right-0">PRESS</li>
                <li class="px-3 py-1 relative after:absolute after:w-0.5 after:h-0.5 after:rounded-full after:bg-white after:top-2.5 after:right-0">VOLUNTEER</li>
                <li class="px-3 py-1 ">BADGE</li>
            </ul>
            <img :src="require(`@/assets/images/220711_BIFAN_Character.gif`)" alt="BIFAN 캐릭터" class="absolute right-0 -bottom-[7px]">
        </div>
    </div>
    <div class="w-full h-[80px] bg-white pt-[12px]">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <!-- 로고 -->
            <img src="../assets/images/230329_BIFAN_logo_kr.gif" alt="부천국제판타스틱영화제">
            <!-- 검색바 -->
            <div class="relative w-[368px]">
                <input type="text" placeholder="#이상해도괜찮아 #영화제목검색" class="w-full border-b-2 border-black p-1 placeholder:text-gray-500">
            </div>
            <!-- 로컬 메뉴 -->
            <ul class="flex text-xs gap-2 font-bold">
                <li><a href="#">JOIN</a></li>
                <li><a href="#">LOGIN</a></li>
                <li><a href="#">ENG</a></li>
            </ul>
        </div>
    </div>
    <!-- 내비게이션 -->
    <div class="w-full h-[60px] bg-black text-white pt-[12px]">
        <ul class="max-w-7xl mx-auto flex justify-between">
            <li v-for="(e,i) in NavData[0].Navi" :key="e" @mouseover="focusOn = true; Num = i" @mouseleave="focusOn=false" class="relative px-5 py-3 transition-all group hover:bg-[#73c4bf]">
                <a href="#">{{ e }}</a>
                <ul class="Spoqa absolute left-0 top-9 bg-[#73c4bf] w-[200px] pl-6 transition-all duration-500 h-0 group-hover:h-auto z-10" @mouseover="focusOn = true;" @mouseleave="focusOn=false">
                    <li v-for="el in NavData[0].SubMenu[i]" :key="el" class="py-2 transition-all duration-500" :class="focusOn === true && Num === i ? 'visible ' : 'hidden'">
                    <a href="#">{{ el }}</a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</template>
<script>
import NavContents from '../assets/nav.json'
export default {
    name : "NaviPage",
    data() {
        return {
            NavData : NavContents,
            focusOn : false,
            Num:null
        }
    },
    methods: {
        SubMenu(e){
            if(e != 0){
                const list = document.querySelectorAll(".sub_list")[e-1];
                const length = list.querySelectorAll("li").length;
                console.log(length);
                this.isSubMenu = `height:${length*39}px`;

                if(list.style.height === '0px'){
                    list.style.height = '116px';
                }else{
                    list.style.height = '0px';
                }
            }
        }
    },    
}
</script>
<style>
    div.w-full{
        font-family: 'Cafe24Ohsquareair';
    }
    .Spoqa{
        font-family: 'SpoqaHanSansNeo-Regular';
    }
</style>